package Comportamiento;

import Agentes.AgenteVendedor;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import javax.swing.JOptionPane;

public class ServidorOrdenesCompra extends CyclicBehaviour {

    AgenteVendedor bsAgent;

    public ServidorOrdenesCompra(AgenteVendedor a) {
        bsAgent = a;
    }

    public void action() {
        MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.ACCEPT_PROPOSAL);
        ACLMessage msg = bsAgent.receive(mt);

        if (msg != null) {
            String title = msg.getContent();
            ACLMessage reply = msg.createReply();

            Integer price = (Integer) bsAgent.getCatalogue().remove(title);
            if (price != null) {
                reply.setPerformative(ACLMessage.INFORM);
                System.out.println(title + " sold to agent " + msg.getSender().getName());
                JOptionPane.showMessageDialog(null, title + " sold to agent " + msg.getSender().getName(), "It has been sold", JOptionPane.INFORMATION_MESSAGE);
            } else {
                reply.setPerformative(ACLMessage.FAILURE);
                reply.setContent("not-available");
            }
            bsAgent.send(reply);
        } else {
            block();
        }
    }
}
